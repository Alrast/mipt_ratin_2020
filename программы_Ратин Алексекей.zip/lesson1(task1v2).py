x=int(input())
y=float()
import numpy as np
y=np.log(np.exp((np.sin(x)+1)**-1)/(1.25+1/(5*x)))/np.log(1+x**2)
print(y)
