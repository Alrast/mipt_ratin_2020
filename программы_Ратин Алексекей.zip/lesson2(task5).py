import turtle
k=0
x=0
y=0
while k<=10:
    x+=-10
    y+=-10
    turtle.penup()
    turtle.goto(x,y)
    turtle.pendown()
    turtle.forward(10+20*k)
    turtle.left(90)
    turtle.forward(10+20*k)
    turtle.left(90)
    turtle.forward(10+20*k)
    turtle.left(90)
    turtle.forward(10+20*k)
    turtle.left(90)
    k+=1
