import numpy as np
y=eval(input())
x= np.arange(-150, 150, 1)
with plt.xkcd():
    plt.plot(x, y)
plt.show()
