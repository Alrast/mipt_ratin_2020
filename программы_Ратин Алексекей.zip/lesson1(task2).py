import matplotlib.pyplot as plt
import numpy as np
x = np.arange(-111, 100, 1)
plt.plot(x, x*x - x - 6)
plt.show()
