import turtle
l=12
f=4
R=1
def turtlecircle(l, f, R):
    for i in range(360//f):
        turtle.forward(l)
        turtle.left(f*R)
def turtlebow(l, f, R):
    for i in range(180//f):
        turtle.forward(l)
        turtle.left(f*R)
turtle.left(90)
turtle.begin_fill()
turtlecircle(l, f, R)
turtle.color("yellow")
turtle.end_fill()
turtle.color("black")
turtle.penup()
turtle.goto(-200,100)
turtle.pendown()
turtle.begin_fill()
turtlecircle(l/6, f, R)
turtle.color("blue")
turtle.end_fill()
turtle.color("black")
turtle.penup()
turtle.goto(-80,100)
turtle.pendown()
turtle.begin_fill()
turtlecircle(l/6, f, R)
turtle.color("blue")
turtle.end_fill()
turtle.color("black")
turtle.penup()
turtle.goto(-170,90)
turtle.pendown()
turtle.left(180)
turtle.width(20)
turtle.forward(100)
turtle.penup()
turtle.color("red")
turtle.goto(-80,-20)
turtle.pendown()
R+=-2
turtlebow(l/2, f, R)
