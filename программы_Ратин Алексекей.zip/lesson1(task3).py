import matplotlib.pyplot as plt
import numpy as np
x = np.arange(-150, 150, 1)
plt.plot(x, np.log((x**2+1)*np.exp(-abs(x)/10))/np.log(1+np.tan((1+np.sin(x)**2)**-1)))
plt.show()
