import turtle
l=int(input())
f=int(input())
R=-1
def turtlebow(l, f, R):
    for i in range(180//f):
        turtle.forward(l)
        turtle.left(f*R)
turtle.left(90)
for i in range(5):
    turtlebow(l, f, R)
    turtlebow(l/4, f, R)
