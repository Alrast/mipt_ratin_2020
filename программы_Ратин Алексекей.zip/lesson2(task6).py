import turtle
turtle.shape("turtle")
for i in range (12):
    turtle.forward(100)
    turtle.right(180)
    turtle.stamp()
    turtle.forward(100)
    turtle.right(210)
