import turtle
s=int(input())
def turtlestar(n,p):
    for i in range(n):
        turtle.forward(s)
        turtle.left(180-180/n)
n=5
turtlestar(n,s)
turtle.penup()
turtle.goto(250, 0)
turtle.pendown()
n+=6
turtlestar(n,s)
