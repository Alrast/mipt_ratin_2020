import turtle
import math
turtle.shape("turtle")
k=3
n=0
while 1<2:
    turtle.left(90+180/k)
    turtle.forward(10+10*n)
    for i in range (k-1):
        turtle.left(360/k)
        turtle.forward(10+10*n)
    turtle.right(90-180/k)
    turtle.penup()
    turtle.forward(10*(n+1)/(2*math.sin(3.14/(k+1)))-10*n/(2*math.sin(3.14/k)))
    turtle.pendown()
    n+=1
    k+=1
