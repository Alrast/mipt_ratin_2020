import turtle
turtle.shape("turtle")
k=1
for i in range (99999):
    turtle.forward(2*k)
    turtle.left(90)
    turtle.forward(2*k)
    k+=1
