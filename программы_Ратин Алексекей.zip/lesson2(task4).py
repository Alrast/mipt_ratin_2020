import turtle
k=0
while k<=360:
    turtle.left(1)
    turtle.forward(4)
    k+=1
