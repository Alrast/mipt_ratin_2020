import turtle
l=int(input())
f=int(input())
R=0
def turtlecircle(l, f, R):
    for i in range(360//f):
        turtle.forward(l)
        turtle.left(f*R)
turtle.left(90)
for i in range(10):
    l+=2
    R+=1
    turtlecircle(l, f, R)
    R+=-2
    turtlecircle(l, f, R)
    R+=1
