import turtle
turtle.shape("turtle")
k=0
s=0
for i in range (99999):
    while k<=180:
        turtle.forward(1+2*s)
        turtle.left(2)
        k+=2
    k+=-180
    s+=1
